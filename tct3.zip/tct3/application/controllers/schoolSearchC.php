<?php


class schoolSearchC extends CI_Controller
{
    public function __construct()
    {
    /*call CodeIgniter's default Constructor*/
    parent::__construct();
    
    /*load database libray manually*/
    $this->load->database();
    
    /*load Model*/
    $this->load->model('schoolSearchM');
    }

    /*Insert for adding members to the database*/
    public function saveMemberData()
    {
        /*load view form for adding a member*/
        $this->load->view('schoolSearchV');
    
        /*Check submit button*/
        if($this->input->post('saveMember'))
        {
            $data['name']=$this->input->post('name');
            $data['email']=$this->input->post('email');
            $data['school']=$this->input->post('school');
            $response=$this->schoolSearchM->saveRecords($data);
            if($response==true){
                    echo "Records Saved Successfully";
            }
            else{
                    echo "Insert error !";
            }
        }
    }
    /*Select*/
    public function showMemberAssociation()
    {
        /*load view form for looking up members*/
        $this->load->view('schoolSearchV');
    
        /*Check submit button*/
        if($this->input->post('showMember'))
        {
            $data['school']=$this->input->post('school');
            $response=$this->schoolSearchM->showRecords($data);
            if($response==true){
                    echo "Records Shown Successfully";
            }
            else{
                    echo "Select error !";
            }
        }
    }
    
}

?>