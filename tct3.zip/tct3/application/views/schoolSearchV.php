<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ToucanTech Test</title>
	<link rel="stylesheet" type="text/css" href="http://localhost/tct3/tct3CSS.css">
</head>
<body>

	<header class=""><!-- The main heading for the page -->
		<h1 class="center">ToucanTech Test</h1><!-- title for when website sized -->
	</header>

	<nav class=""><!--The primary navigation for the website -->
		<ul class="nav1"> 
			<li class=""><a class="" href="http://localhost/tct3/index.php/schoolSearchC/saveMemberData">Add Member</a></li>
			<li class=""><a class="" href="http://localhost/tct3/index.php/schoolSearchC/showMemberAssociation">Show Members</a></li>
		</ul>
	</nav>

	<!-- This form is to save member data into the database -->
	<div id="addMember" class="center block">
		<form id="addMemberForm" method="post" class="" action="http://localhost/tct3/index.php/schoolSearchC/saveMemberData">
			<div class="">
				<label for="name">Name: </label>
				<input type="text" id="name" name="name" class="">
			</div>
			<div class="">
				<label for="email">Email: </label>
				<input type="email" id="email" name="email" class="">
			</div>
			<div class="">
				<label for="school">School: </label>
				<!-- <select id="school" name="school" multiple size="5"> -->
				<input list="schools" name="school" id="school">
				<datalist id="schools"> 
					<option value="School 1"></option>
					<option value="School 2"></option>
					<option value="School 3"></option>
					<option value="School 4"></option>
					<option value="School 5"></option>
				</datalist>
			</div>
			<div>
				<input type="submit" name="saveMember" value="Send Member">
			</div>
		
		</form>
	</div>

	<!-- This form is to show members associated with the chosen school -->
	<div id="showMember" class=" center block">
		<form id="showMemberForm" method="post" class="" action="http://localhost/tct3/index.php/schoolSearchC/showMemberAssociation">
			<div class="">
				<label for="school">School: </label>
				<input list="schools" name="school" id="school">
				<datalist id="schools"> 
					<option value="School 1"></option>
					<option value="School 2"></option>
					<option value="School 3"></option>
					<option value="School 4"></option>
					<option value="School 5"></option>
				</datalist>
			</div>
			<div>
				<input type="submit" name="showMember" value="Show Member">
			</div>
		
		</form>
		
	</div>

</body>
</html>