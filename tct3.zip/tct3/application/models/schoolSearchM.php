<?php

class schoolSearchM extends CI_Model{

	// this function is used for adding members to the database
	// first the member is added to the members table, then the created member_id
	// is then used for inserting the member_id and school_id into the 
	// associations table to keep the relationship between the member and school
	function saveRecords($data)
	{
		$sql1 = "INSERT INTO members (name, email) VALUES (?, ?)";
		$this->db->query($sql1, array($data['name'], $data['email']));
        $member_id = $this->db->insert_id();
        $school_idObj = $this->db->query("SELECT school_id FROM schools WHERE school = '".$data['school']."'");
        $school_idArr = $school_idObj->result_array();
        // var_dump used to see array format
        //var_dump($school_idArr);
        $school_id = $school_idArr[0]['school_id'];
        $this->db->query("INSERT INTO associations (member_id, school_id) VALUES ($member_id, $school_id)");

        return true;
	}

	// this funtion is used to show members from a chosen school
	// first the shcool_id is retrieved from the schools table and then used
	// to get the members name/s who happen to be associated with the chosen 
	// school, then the names are echo's into the page
	function showRecords($data)
	{
		$school_idObj = $this->db->query("SELECT school_id FROM schools WHERE school = '".$data['school']."'");
        $school_idArr = $school_idObj->result_array();
        // var_dump used to see array format
        //var_dump($school_idArr);
        $school_id = $school_idArr[0]['school_id'];
		$membersObj = $this->db->query("SELECT members.name, associations.school_id FROM associations INNER JOIN members ON associations.member_id=members.member_id where associations.school_id = '".$school_id."'");
        $membersArr = $membersObj->result_array();
        //var_dump($membersArr);
        foreach ($membersArr as $names){
        	echo $names['name'];
        	echo "<br>";
        }

        return true;
	}
}

?>

<!-- testing diffrent sql queries -->
<!-- working join query
SELECT members.name, associations.school_id FROM associations INNER JOIN members ON associations.member_id=members.member_id where associations.school_id = 3;


working view query
CREATE OR REPLACE VIEW m6 AS 
SELECT members.name, associations.school_id FROM associations INNER JOIN members ON associations.member_id=members.member_id where associations.school_id = 1; -->